/**
 * Cookie-consent voor BrabantSchoon.
 * ------------------------------------
 * AVG/GDPR-uitgangspunt: Google Analytics (of enige andere niet-noodzakelijke
 * cookie/tracker) wordt UITSLUITEND geladen nadat de bezoeker hier expliciet
 * toestemming voor heeft gegeven. Vóór die toestemming wordt er geen enkel
 * Analytics-script geladen en worden er dus ook geen Analytics-cookies gezet.
 *
 * De voorkeur wordt opgeslagen in localStorage (niet in een cookie zelf -
 * dat is voor het onthouden van de keuze zelf niet vergunningsplichtig).
 */
(function () {
  var STORAGE_KEY = 'brabantschoon_cookie_consent'; // waarde: 'accepted' | 'rejected'
  var scriptTag = document.currentScript;
  var gaId = scriptTag ? scriptTag.getAttribute('data-ga-id') : null;

  var banner = document.getElementById('cookieBanner');
  var acceptBtn = document.getElementById('cookieAccept');
  var rejectBtn = document.getElementById('cookieReject');

  function loadGoogleAnalytics() {
    if (!gaId || window.__gaLoaded) return;
    window.__gaLoaded = true;

    var s = document.createElement('script');
    s.async = true;
    s.src = 'https://www.googletagmanager.com/gtag/js?id=' + gaId;
    document.head.appendChild(s);

    window.dataLayer = window.dataLayer || [];
    function gtag() { window.dataLayer.push(arguments); }
    window.gtag = gtag;
    gtag('js', new Date());
    // anonymize_ip is impliciet standaard in GA4, maar expliciet meegeven kan geen kwaad
    gtag('config', gaId, { anonymize_ip: true });
  }

  // Verwijdert bestaande Google Analytics-cookies, voor het geval een bezoeker
  // eerst toestemming gaf en die later weer intrekt.
  function removeAnalyticsCookies() {
    var cookies = document.cookie.split(';');
    cookies.forEach(function (c) {
      var name = c.split('=')[0].trim();
      if (name.indexOf('_ga') === 0) {
        document.cookie = name + '=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
        document.cookie = name + '=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/; domain=' + location.hostname + ';';
      }
    });
  }

  function hideBanner() {
    if (banner) banner.hidden = true;
  }

  function showBanner() {
    if (banner) banner.hidden = false;
  }

  function getConsent() {
    try { return localStorage.getItem(STORAGE_KEY); } catch (e) { return null; }
  }
  function setConsent(value) {
    try { localStorage.setItem(STORAGE_KEY, value); } catch (e) { /* privémodus o.i.d.: negeren */ }
  }

  function applyStoredConsent() {
    var consent = getConsent();
    if (consent === 'accepted') {
      loadGoogleAnalytics();
      hideBanner();
    } else if (consent === 'rejected') {
      hideBanner();
    } else {
      showBanner();
    }
  }

  if (acceptBtn) {
    acceptBtn.addEventListener('click', function () {
      setConsent('accepted');
      loadGoogleAnalytics();
      hideBanner();
    });
  }
  if (rejectBtn) {
    rejectBtn.addEventListener('click', function () {
      setConsent('rejected');
      removeAnalyticsCookies();
      hideBanner();
    });
  }

  // Maakt het mogelijk om de voorkeur later te wijzigen, bijvoorbeeld via een
  // link in de footer: <a href="#" onclick="window.reopenCookieBanner()">
  window.reopenCookieBanner = function () {
    showBanner();
  };

  applyStoredConsent();
})();
